package com.assecosee.sxs.client.examples;

public class PaymentConfirmationResponse {

    private Status status;
    private PaymentConfirmationError error;

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public PaymentConfirmationError getError() {
        return error;
    }

    public void setError(PaymentConfirmationError error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "PaymentConfirmationResponse{" +
                "status=" + status +
                ", error=" + error +
                '}';
    }

    public enum Status {
        OK, FAILURE;
    }
}
