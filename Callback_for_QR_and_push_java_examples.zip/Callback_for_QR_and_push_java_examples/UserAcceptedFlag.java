package com.assecosee.sxs.client.examples;

public enum UserAcceptedFlag {

    Y, N;
}
