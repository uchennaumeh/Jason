package com.assecosee.sxs.client.examples;

import java.util.Objects;

public class PaymentConfirmation {

  private String apiKey;
  private String transactionId;
  private UserAcceptedFlag userAccepted;
  private String tokenSN;
  private String mac;
  private Boolean sxsValidation;

  public static PaymentConfirmation createUserAcceptedMacValidationPassed(String apiKey, String transactionId, String tokenSN, String mac) {
    PaymentConfirmation paymentConfirmation = new PaymentConfirmation();
    paymentConfirmation.setUserAccepted(UserAcceptedFlag.Y);
    paymentConfirmation.setApiKey(apiKey);
    paymentConfirmation.setMac(mac);
    paymentConfirmation.setTokenSN(tokenSN);
    paymentConfirmation.setTransactionId(transactionId);
    paymentConfirmation.sxsValidation = true;
    return paymentConfirmation;
  }

  public static PaymentConfirmation createUserAcceptedMacValidationFailed(String apiKey, String transactionId, String tokenSN, String mac) {
    PaymentConfirmation paymentConfirmation = new PaymentConfirmation();
    paymentConfirmation.setUserAccepted(UserAcceptedFlag.Y);
    paymentConfirmation.setApiKey(apiKey);
    paymentConfirmation.setMac(mac);
    paymentConfirmation.setTokenSN(tokenSN);
    paymentConfirmation.setTransactionId(transactionId);
    paymentConfirmation.sxsValidation = false;
    return paymentConfirmation;
  }

  public static PaymentConfirmation createUserRejected(String apiKey, String transactionId, String tokenSN) {
    PaymentConfirmation paymentConfirmation = new PaymentConfirmation();
    paymentConfirmation.setUserAccepted(UserAcceptedFlag.N);
    paymentConfirmation.setApiKey(apiKey);
    paymentConfirmation.setTokenSN(tokenSN);
    paymentConfirmation.setTransactionId(transactionId);
    paymentConfirmation.sxsValidation = null;
    return paymentConfirmation;
  }

  public static PaymentConfirmation createUserAcceptedNotValidated(String apiKey, String transactionId, String tokenSN, String mac) {
    PaymentConfirmation paymentConfirmation = new PaymentConfirmation();
    paymentConfirmation.setUserAccepted(UserAcceptedFlag.Y);
    paymentConfirmation.setApiKey(apiKey);
    paymentConfirmation.setMac(mac);
    paymentConfirmation.setTokenSN(tokenSN);
    paymentConfirmation.setTransactionId(transactionId);
    paymentConfirmation.sxsValidation = null;
    return paymentConfirmation;
  }

  public String getTokenSN() {
    return tokenSN;
  }

  public void setTokenSN(String tokenSN) {
    this.tokenSN = tokenSN;
  }

  public String getApiKey() {
    return apiKey;
  }

  public void setApiKey(String apiKey) {
    this.apiKey = apiKey;
  }

  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public UserAcceptedFlag getUserAccepted() {
    return userAccepted;
  }

  public void setUserAccepted(UserAcceptedFlag userAccepted) {
    this.userAccepted = userAccepted;
  }

  public String getMac() {
    return mac;
  }

  public void setMac(String mac) {
    this.mac = mac;
  }

  public Boolean getSxsValidation() {
    return sxsValidation;
  }

  public void setSxsValidation(Boolean sxsValidation) {
    this.sxsValidation = sxsValidation;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    PaymentConfirmation that = (PaymentConfirmation) o;
    return Objects.equals(apiKey, that.apiKey) &&
        Objects.equals(transactionId, that.transactionId) &&
        Objects.equals(userAccepted, that.userAccepted) &&
        Objects.equals(tokenSN, that.tokenSN) &&
        Objects.equals(mac, that.mac) &&
        Objects.equals(sxsValidation, that.sxsValidation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(apiKey, transactionId, userAccepted, tokenSN, mac, sxsValidation);
  }
}