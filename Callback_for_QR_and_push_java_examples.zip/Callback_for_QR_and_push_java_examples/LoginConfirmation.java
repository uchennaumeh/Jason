package com.assecosee.sxs.client.examples;

import java.util.Objects;

public class LoginConfirmation {

  private String apiKey;
  private String tokenSN;
  private String otp;
  private String loginId;

  public static LoginConfirmation createUserAccepted(String apiKey, String tokenSN, String otp, String loginId) {
    LoginConfirmation loginConfirmation = new LoginConfirmation();
    loginConfirmation.setApiKey(apiKey);
    loginConfirmation.setTokenSN(tokenSN);
    loginConfirmation.setLoginId(loginId);
    loginConfirmation.setOtp(otp);
    return loginConfirmation;
  }


  public String getApiKey() {
    return apiKey;
  }

  public void setApiKey(String apiKey) {
    this.apiKey = apiKey;
  }

  public String getTokenSN() {
    return tokenSN;
  }

  public void setTokenSN(String tokenSN) {
    this.tokenSN = tokenSN;
  }

  public String getOtp() {
    return otp;
  }

  public void setOtp(String otp) {
    this.otp = otp;
  }

  public String getLoginId() {
    return loginId;
  }

  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    LoginConfirmation that = (LoginConfirmation) o;
    return Objects.equals(apiKey, that.apiKey) &&
        Objects.equals(tokenSN, that.tokenSN) &&
        Objects.equals(otp, that.otp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(apiKey, tokenSN, otp);
  }
}