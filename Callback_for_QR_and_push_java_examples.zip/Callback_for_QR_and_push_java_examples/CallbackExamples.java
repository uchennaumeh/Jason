package com.assecosee.sxs.client.examples;


import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// /sxs/mtoken path is only an example, other path value can be used
@Path("/sxs/mtoken/")
public class CallbackExamples {

    /*suppose IB application is available under http://localhost:8080/ibank-adm,
	in that case - callback URL for QR and push notification
    that needs to be configured on the SxS side will be:

    http://localhost:8080/ibank-adm/sxs/mtoken/callback

    callback as a path here is only an example, other path value can be used
     */
    @POST
    @Path("callback")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public PaymentConfirmationResponse callbackNotification(PaymentConfirmation paymentConfirmationRequest) {

        //implement callback logic
        //...

        PaymentConfirmationResponse paymentConfirmationResponse = new PaymentConfirmationResponse();
        //if everything was ok
        paymentConfirmationResponse.setStatus(PaymentConfirmationResponse.Status.OK);

        return paymentConfirmationResponse;
    }

    /*suppose IB application is available under http://localhost:8080/ibank-adm,
	in that case - callback URL for QR login
    that needs to be configured on the SxS side will be:

    http://localhost:8080/ibank-adm/sxs/mtoken/callback/login

    callback/login as a path here is only an example, other path value can be used
     */
    @POST
    @Path("callback/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public LoginConfirmationResponse callbackNotificationForLogin(LoginConfirmation loginConfirmationRequest) {

        //implement callback logic
        //...

        LoginConfirmationResponse loginConfirmationResponse = new LoginConfirmationResponse();
        //if everything was ok
        loginConfirmationResponse.setStatus(LoginConfirmationResponse.Status.OK);

        return loginConfirmationResponse;
    }
}
