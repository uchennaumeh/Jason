package com.assecosee.sxs.client.examples;

public class LoginConfirmationResponse {

    private Status status;
    private LoginConfirmationError error;

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public LoginConfirmationError getError() {
        return error;
    }

    public void setError(LoginConfirmationError error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "LoginConfirmationResponse{" +
                "status=" + status +
                ", error=" + error +
                '}';
    }

    public enum Status {
        OK, FAILURE;
    }
}
